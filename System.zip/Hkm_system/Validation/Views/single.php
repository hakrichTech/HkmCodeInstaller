<span class="help-block"><?= hkm_esc($error) ?></span>
