<?php


namespace Hkm_code\Exceptions;

use Error;

/**
 * Error: Critical conditions, like component unavailable, etc.
 */
class CriticalError extends Error
{
}
