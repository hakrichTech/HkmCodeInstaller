<?php


namespace Hkm_code\Exceptions;

use Error;

/**
 * Error: Action must be taken immediately (system/db down, etc)
 */
class AlertError extends Error
{
}
