<?php


namespace Hkm_code\Exceptions;

use Error;

/**
 * Error: system is unusable
 */
class EmergencyError extends Error
{
}
