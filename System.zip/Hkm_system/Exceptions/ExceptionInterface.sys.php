<?php



namespace Hkm_code\Exceptions;

interface ExceptionInterface
{
}
