<@php

namespace {namespace};

use Hkm_code\Vezirion\BaseVezirion;

class {class} extends BaseVezirion
{
	//
}
