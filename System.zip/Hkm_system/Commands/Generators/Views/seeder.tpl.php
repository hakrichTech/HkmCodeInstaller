<@php

namespace {namespace};

use Hkm_code\Database\Seeder;

class {class} extends Seeder
{
	public static function RUN()
	{
		//
	}
}
