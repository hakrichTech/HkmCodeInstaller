<@php

namespace {AppNamespace}\Controllers;

class Home extends BaseController
{
	public static function INDEX()
	{
		return view('welcome_message');
	}
}
